﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Class1
    {
        public const string mailprov = @"^[a-zA-Z]";
        public bool IsMail(string number)
        {
            if (number != null) return Regex.IsMatch(number, mailprov);
            else return true;
        }
    }
}
