﻿using Diplomm.BD;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplomm.Forms
{
    /// <summary>
    /// Логика взаимодействия для Stanok.xaml
    /// </summary>
    public partial class Stanok : Window
    {
        BD.user168_dbEntities db = new BD.user168_dbEntities();
        public Stanok()
        {
            db = new BD.user168_dbEntities();
            InitializeComponent();
            StanokSta.ItemsSource = db.Diplom_Stanok.ToList();
            var Sot = db.Diplom_Tip_Stanka.ToList();
            ComboTipStanok.ItemsSource = Sot;
            ComboTipStanok.DisplayMemberPath = "tip";
            var Sat = db.Diplom_Statysa_Stanka.ToList();
            ComboStatysStanok.ItemsSource = Sat;
            ComboStatysStanok.DisplayMemberPath = "Status";
            var Sit = db.Diplom_Ychastok.ToList();
            ComboNazStanok.ItemsSource = Sit;
            ComboNazStanok.DisplayMemberPath = "Nazvanie";

            var itemNaz = db.Diplom_Stanok.Select(n => n.Nazvanie).ToList();
            foreach (String ITEM in itemNaz)
            {
                ComboFilteStanok.Items.Add(ITEM);
            }
            if (App.CurrentUser.Rol == 1 || App.CurrentUser.Rol == 2) //Если роль 1 (например Админ)
            { //То кнопки редактирования и просмотра видны
                DobavStanok.Visibility = Visibility.Visible;
                YdalStanok.Visibility = Visibility.Visible;
            }
            else //Для всех других ролей
            { //Данные кнопки не видны
                DobavStanok.Visibility = Visibility.Collapsed;
                YdalStanok.Visibility = Visibility.Collapsed;
            }
        }

        private void DobavStanok_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (txtNazStanok.Text == "" || ComboTipStanok.Text == "" || txtModStanok.Text == "" || ComboStatysStanok.Text == "" || ComboNazStanok.Text == "")
                {
                    System.Windows.MessageBox.Show("Вы ввели не все данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    var f = db.Diplom_Tip_Stanka.Where(a => a.tip == ComboTipStanok.Text).Select(a => a.ID_Tipa_Stanka).SingleOrDefault();
                    var h = db.Diplom_Statysa_Stanka.Where(a => a.Status == ComboStatysStanok.Text).Select(a => a.ID_Statysa_Stanka).SingleOrDefault();
                    var j = db.Diplom_Ychastok.Where(a => a.Nazvanie == ComboNazStanok.Text).Select(a => a.ID_Ychastka).SingleOrDefault();
                    Diplom_Stanok Sot = new Diplom_Stanok();
                    Sot.Nazvanie = txtNazStanok.Text;
                    Sot.Tip = Convert.ToInt32(f);
                    Sot.Model = txtModStanok.Text;
                    Sot.Statys = Convert.ToInt32(h);
                    Sot.id_ychastka = Convert.ToInt32(j);

                    db.Diplom_Stanok.Add(Sot);
                    db.SaveChanges();
                    System.Windows.MessageBox.Show("Данные добавлены!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch
            {
                System.Windows.MessageBox.Show("Ошибка", "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            txtNazStanok.Text = "";
            ComboTipStanok.Text = "";
            txtModStanok.Text = "";
            ComboStatysStanok.Text = "";
            ComboNazStanok.Text = "";
        }

        private void IzmenStanok_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtIdStanok.Text))
                {
                    MessageBox.Show("Введите ID номенклатуры для изменения", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                int b = Convert.ToInt32(txtIdStanok.Text);
                var Izmen = db.Diplom_Stanok.FirstOrDefault(id => id.ID_Stanka == b);

                if (Izmen == null)
                {
                    MessageBox.Show("Номенклатура с таким ID не найдена", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (!string.IsNullOrWhiteSpace(txtNazStanok.Text))
                {
                    Izmen.Nazvanie = txtNazStanok.Text;
                }

                if (ComboTipStanok.SelectedItem != null)
                {
                    var f = db.Diplom_Tip_Stanka.Where(a => a.tip == ComboTipStanok.Text).Select(a => a.ID_Tipa_Stanka).SingleOrDefault();
                    Izmen.Tip = Convert.ToInt32(f);
                }

                if (!string.IsNullOrWhiteSpace(txtModStanok.Text))
                {
                    Izmen.Model = txtModStanok.Text;
                }

                if (ComboStatysStanok.SelectedItem != null)
                {
                    var h = db.Diplom_Statysa_Stanka.Where(a => a.Status == ComboStatysStanok.Text).Select(a => a.ID_Statysa_Stanka).SingleOrDefault();
                    Izmen.Statys = Convert.ToInt32(h);
                }
                if (ComboNazStanok.SelectedItem != null)
                {
                    var j = db.Diplom_Ychastok.Where(a => a.Nazvanie == ComboNazStanok.Text).Select(a => a.ID_Ychastka).SingleOrDefault();
                    Izmen.id_ychastka = Convert.ToInt32(j);
                }
                db.SaveChanges();
                MessageBox.Show("Данные изменены!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);

                // Очистка полей после успешного обновления
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void ClearFields()
        {
            txtIdStanok.Text = "";
            txtNazStanok.Text = "";
            ComboTipStanok.SelectedItem = null;
            txtModStanok.Text = "";
            ComboStatysStanok.SelectedItem = null;
            ComboNazStanok.SelectedItem = null;
        }

        private void YdalStanok_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (txtIdStanok.Text == "")
                {
                    System.Windows.MessageBox.Show("Вы ввели не все данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);

                }
                else
                {
                    int num = Convert.ToInt32(txtIdStanok.Text);
                    var sot = db.Diplom_Stanok.Where(w => w.ID_Stanka == num).FirstOrDefault();
                    db.Diplom_Stanok.Remove(sot);
                    db.SaveChanges();
                    MessageBox.Show("Запись успешно удалена!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch
            {
                System.Windows.MessageBox.Show("Ошибка", "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            txtIdStanok.Text = "";
        }

        private void ObnovStanok_Click(object sender, RoutedEventArgs e)
        {
            StanokSta.ItemsSource = db.Diplom_Stanok.ToList();
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            Forms.Glavnaya glav = new Forms.Glavnaya();
            glav.Show();
            this.Close();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }

        private void ComboFilterStanok_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ComboFilteStanok.SelectedIndex == 0 || ComboFilteStanok.SelectedItem.ToString() == "Все")
            {
                StanokSta.ItemsSource = db.Diplom_Stanok.ToList();
            }
            else
            {
                string selectedFamiliya = ComboFilteStanok.SelectedItem.ToString();
                StanokSta.ItemsSource = db.Diplom_Stanok
                                           .Where(n => n.Nazvanie == selectedFamiliya)
                                           .ToList();
            }
        }

        private void SortAZ_Click(object sender, RoutedEventArgs e)
        {
            StanokSta.ItemsSource = db.Diplom_Stanok.OrderBy(ChenB => ChenB.Nazvanie).ToList();
        }

        private void SortZA_Click(object sender, RoutedEventArgs e)
        {
            StanokSta.ItemsSource = db.Diplom_Stanok.OrderByDescending(ChenB => ChenB.Nazvanie).ToList();
        }

        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            string Poisk = txtSearch.Text;
            StanokSta.ItemsSource = db.Diplom_Stanok.ToList().Where(
                q => q.Nazvanie.ToLower().Contains(Poisk.ToLower()) || q.Diplom_Tip_Stanka.tip.ToLower().Contains(Poisk.ToLower()) || q.Model.ToLower().Contains(Poisk.ToLower()) || q.Diplom_Statysa_Stanka.Status.ToLower().Contains(Poisk.ToLower()) || q.Diplom_Ychastok.Nazvanie.ToLower().Contains(Poisk.ToLower())
                ).ToList();
        }

        private void txtIdInstr_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9/]+");
            e.Handled = regex.IsMatch(e.Text);
        }
    }
}
