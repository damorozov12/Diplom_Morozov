﻿using Diplomm.BD;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplomm.Forms
{
    /// <summary>
    /// Логика взаимодействия для Sklad.xaml
    /// </summary>
    public partial class Sklad : Window
    {
        BD.user168_dbEntities db = new BD.user168_dbEntities();
        public Sklad()
        {
            db = new BD.user168_dbEntities();
            InitializeComponent();
            SkladSkl.ItemsSource = db.Diplom_Sklad.ToList();
            var Sklad = db.Diplom_Statys_Sklada.ToList();
            ComboStatysSklad.ItemsSource = Sklad;
            ComboStatysSklad.DisplayMemberPath = "Statys";

            var itemKat = db.Diplom_Sklad.Select(n => n.Kategoriya).ToList();
            foreach (String ITEM in itemKat)
            {
                ComboFilterSklad.Items.Add(ITEM);
            }
            if (App.CurrentUser.Rol == 1 || App.CurrentUser.Rol == 2) //Если роль 1 (например Админ)
            { //То кнопки редактирования и просмотра видны
                DobavSklad.Visibility = Visibility.Visible;
                YdalSklad.Visibility = Visibility.Visible;
            }
            else //Для всех других ролей
            { //Данные кнопки не видны
                DobavSklad.Visibility = Visibility.Collapsed;
                YdalSklad.Visibility = Visibility.Collapsed;
            }
        }

        private void DobavSklad_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (txtKolSklad.Text == "" || txtPostSklad.Text == "" || txtKatSklad.Text == "" || ComboStatysSklad.Text == "" || txtMestSklad.Text == "" )
                {
                    System.Windows.MessageBox.Show("Вы ввели не все данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    var f = db.Diplom_Statys_Sklada.Where(a => a.Statys == ComboStatysSklad.Text).Select(a => a.ID_Statysa_Sklada).SingleOrDefault();
                    Diplom_Sklad Sot = new Diplom_Sklad();
                    Sot.Kolichestvo_instr = txtKolSklad.Text;
                    Sot.Postavschik = txtPostSklad.Text;
                    Sot.Kategoriya = txtKatSklad.Text;
                    Sot.Statys = Convert.ToInt32(f);
                    Sot.Mesto_hraneniya = txtMestSklad.Text;

                    db.Diplom_Sklad.Add(Sot);
                    db.SaveChanges();
                    System.Windows.MessageBox.Show("Данные добавлены!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch
            {
                System.Windows.MessageBox.Show("Ошибка", "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            txtKolSklad.Text = "";
            txtPostSklad.Text = "";
            txtKatSklad.Text = "";
            ComboStatysSklad.Text = "";
            txtMestSklad.Text = "";
        }

        private void IzmenSklad_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtIdSklad.Text))
                {
                    MessageBox.Show("Введите ID номенклатуры для изменения", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                int b = Convert.ToInt32(txtIdSklad.Text);
                var Izmen = db.Diplom_Sklad.FirstOrDefault(id => id.ID_sklada == b);

                if (Izmen == null)
                {
                    MessageBox.Show("Номенклатура с таким ID не найдена", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (!string.IsNullOrWhiteSpace(txtKolSklad.Text))
                {
                    Izmen.Kolichestvo_instr = txtKolSklad.Text;
                }

                if (!string.IsNullOrWhiteSpace(txtPostSklad.Text))
                {
                    Izmen.Postavschik = txtPostSklad.Text;
                }

                if (!string.IsNullOrWhiteSpace(txtKatSklad.Text))
                {
                    Izmen.Kategoriya = txtKatSklad.Text;
                }
                if (ComboStatysSklad.SelectedItem != null)
                {
                    var f = db.Diplom_Statys_Sklada.Where(a => a.Statys == ComboStatysSklad.Text).Select(a => a.ID_Statysa_Sklada).SingleOrDefault();
                    Izmen.Statys = Convert.ToInt32(f);
                }

                if (!string.IsNullOrWhiteSpace(txtMestSklad.Text))
                {
                    Izmen.Mesto_hraneniya = txtMestSklad.Text;
                }
                db.SaveChanges();
                MessageBox.Show("Данные изменены!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);

                // Очистка полей после успешного обновления
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void ClearFields()
        {
            txtIdSklad.Text = "";
            txtKolSklad.Text = "";
            txtPostSklad.Text = "";
            txtKatSklad.Text = "";
            ComboStatysSklad.SelectedItem = null;
            txtMestSklad.Text = "";
        }

        private void YdalSklad_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (txtIdSklad.Text == "")
                {
                    System.Windows.MessageBox.Show("Вы ввели не все данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);

                }
                else
                {
                    int num = Convert.ToInt32(txtIdSklad.Text);
                    var sot = db.Diplom_Sklad.Where(w => w.ID_sklada == num).FirstOrDefault();
                    db.Diplom_Sklad.Remove(sot);
                    db.SaveChanges();
                    MessageBox.Show("Запись успешно удалена!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch
            {
                System.Windows.MessageBox.Show("Ошибка", "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            txtIdSklad.Text = "";
        }

        private void ObnovSklad_Click(object sender, RoutedEventArgs e)
        {
            SkladSkl.ItemsSource = db.Diplom_Sklad.ToList();
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            Forms.Glavnaya glav = new Forms.Glavnaya();
            glav.Show();
            this.Close();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }

        private void ComboFilterSklad_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ComboFilterSklad.SelectedIndex == 0 || ComboFilterSklad.SelectedItem.ToString() == "Все")
            {
                SkladSkl.ItemsSource = db.Diplom_Sklad.ToList();
            }
            else
            {
                string selectedKategoriya = ComboFilterSklad.SelectedItem.ToString();
                SkladSkl.ItemsSource = db.Diplom_Sklad
                                           .Where(n => n.Kategoriya == selectedKategoriya)
                                           .ToList();
            }
        }
        private void SortAZ_Click(object sender, RoutedEventArgs e)
        {
            SkladSkl.ItemsSource = db.Diplom_Sklad.OrderBy(ChenB => ChenB.Kategoriya).ToList();
        }

        private void SortZA_Click(object sender, RoutedEventArgs e)
        {
            SkladSkl.ItemsSource = db.Diplom_Sklad.OrderByDescending(ChenB => ChenB.Kategoriya).ToList();
        }

        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            string Poisk = txtSearch.Text;
            SkladSkl.ItemsSource = db.Diplom_Sklad.ToList().Where(
                q => q.Kolichestvo_instr.ToLower().Contains(Poisk.ToLower()) || q.Postavschik.ToLower().Contains(Poisk.ToLower()) || q.Kategoriya.ToLower().Contains(Poisk.ToLower()) || q.Mesto_hraneniya.ToLower().Contains(Poisk.ToLower()) || q.Diplom_Statys_Sklada.Statys.ToLower().Contains(Poisk.ToLower())
                ).ToList();
        }

        private void txtIdSklad_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9/]+");
            e.Handled = regex.IsMatch(e.Text);
        }
    }
}
