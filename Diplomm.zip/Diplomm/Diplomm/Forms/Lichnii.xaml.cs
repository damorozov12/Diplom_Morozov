﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Diplomm.BD; 

namespace Diplomm.Forms
{
    /// <summary>
    /// Логика взаимодействия для Lichnii.xaml
    /// </summary>
    public partial class Lichnii : Window
    {
        BD.user168_dbEntities db = new BD.user168_dbEntities();
        public Lichnii()
        {
            InitializeComponent();
        }
        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            txtFamLich.Text = App.CurrentUser.Familiya;
            txtImyaLich.Text= App.CurrentUser.Imya;
            txtOtchLich.Text= App.CurrentUser.Otvhestvo;
            txtTelLich.Text= App.CurrentUser.Telefon;
            txtCtajLich.Text= App.CurrentUser.Staj;
            txtRolLich.Text= App.CurrentUser.Diplom_Rol_Sotrudnik.rol;
            txtLogLich.Text = App.CurrentUser.Login;
            txtPassLich.Text= App.CurrentUser.Password;
            // Блокировка текстовых полей, кроме пароля
            txtFamLich.IsEnabled = false;
            txtImyaLich.IsEnabled = false;
            txtOtchLich.IsEnabled = false;
            txtTelLich.IsEnabled = false;
            txtCtajLich.IsEnabled = false;
            txtRolLich.IsEnabled = false;
            txtLogLich.IsEnabled = false;
            // Пароль оставляем доступным для редактирования
            txtPassLich.IsReadOnly = false;
        }

        private void IzmenInstr_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Найти текущего пользователя в базе данных
                var user = db.Diplom_Sotrydnik.SingleOrDefault(u => u.ID_sotrydnika == App.CurrentUser.ID_sotrydnika);
                if (user != null)
                {
                    // Обновить пароль
                    user.Password = txtPassLich.Text;

                    // Сохранить изменения
                    db.SaveChanges();

                    // Обновить текущего пользователя в приложении
                    App.CurrentUser.Password = txtPassLich.Text;
                    System.Windows.MessageBox.Show("Пароль успешно обновлен!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
               
                }
                else
                {
                    System.Windows.MessageBox.Show("Пользователь не найден", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                   
                }
            }
            catch 
            {
                System.Windows.MessageBox.Show("Ошибка", "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            Glavnaya glav = new Glavnaya();
            glav.Show();
            this.Close();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
