﻿using Diplomm.BD;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplomm.Forms
{
    /// <summary>
    /// Логика взаимодействия для Ispolzovanie_Instr.xaml
    /// </summary>
    public partial class Ispolzovanie_Instr : Window
    {
        BD.user168_dbEntities db = new BD.user168_dbEntities();
        public Ispolzovanie_Instr()
        {
            db = new BD.user168_dbEntities();
            InitializeComponent();
            IspolInstrIspInstr.ItemsSource = db.Diplom_Ispolzovanie_Instr.ToList();
            var Nem = db.Diplom_Sotrydnik.ToList();
            ComboIdSot.ItemsSource = Nem;
            ComboIdSot.DisplayMemberPath = "Familiya";
            var Nam = db.Diplom_Stanok.ToList();
            ComboIdStan.ItemsSource = Nam;
            ComboIdStan.DisplayMemberPath = "Nazvanie";
            var Nom = db.Diplom_Instryment.ToList();
            ComboIdInstr.ItemsSource = Nom;
            ComboIdInstr.DisplayMemberPath = "Nazvanie";
            var Nim = db.Diplom_Sklad.ToList();
            ComboIdSklada.ItemsSource = Nim;
            ComboIdSklada.DisplayMemberPath = "Postavschik";

            var itemNaz = db.Diplom_Ispolzovanie_Instr.Select(n => n.Spisanie_instrumenta).Where(date => date.HasValue) // Фильтруем, чтобы исключить возможные NULL значения
           .ToList();

            foreach (DateTime? date in itemNaz)
            {
                if (date.HasValue) // Проверяем, не является ли дата NULL
                {
                    ComboFilterIspInstr.Items.Add(date.Value.ToString("dd.MM.yyyy"));
                }
            }

            if (App.CurrentUser.Rol == 1 || App.CurrentUser.Rol == 2) //Если роль 1 (например Админ)
            { //То кнопки редактирования и просмотра видны
                DobavIspInstr.Visibility = Visibility.Visible;
                YdalIspInstr.Visibility = Visibility.Visible;
            }
            else //Для всех других ролей
            { //Данные кнопки не видны
                DobavIspInstr.Visibility = Visibility.Collapsed;
                YdalIspInstr.Visibility = Visibility.Collapsed;
            }

        }

        private void DobavIspInstr_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (DateDataIspInstr.Text == "" || txtKolIspInstr.Text == "" || DateDataSpisIspInstr.Text == "" || ComboIdSot.Text == "" || ComboIdStan.Text == "" || ComboIdInstr.Text == "" || ComboIdSklada.Text == "" )
                {
                    System.Windows.MessageBox.Show("Вы ввели не все данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    var b = db.Diplom_Sotrydnik.Where(a => a.Familiya == ComboIdSot.Text).Select(a => a.ID_sotrydnika).SingleOrDefault();
                    var d = db.Diplom_Stanok.Where(a => a.Nazvanie == ComboIdStan.Text).Select(a => a.ID_Stanka).SingleOrDefault();
                    var i = db.Diplom_Instryment.Where(a => a.Nazvanie == ComboIdInstr.Text).Select(a => a.ID_Instrumenta).SingleOrDefault();
                    var f = db.Diplom_Sklad.Where(a => a.Postavschik == ComboIdSklada.Text).Select(a => a.ID_sklada).SingleOrDefault();
                    var Data = Convert.ToDateTime(DateDataIspInstr.Text);
                    var Date = Convert.ToDateTime(DateDataSpisIspInstr.Text);
                    Diplom_Ispolzovanie_Instr Nomen = new Diplom_Ispolzovanie_Instr();
                    Nomen.Data_Ispolzovaniya = Data;
                    Nomen.Kolichestvo = txtKolIspInstr.Text;
                    Nomen.Spisanie_instrumenta = Date;
                    Nomen.id_sotrudnika = Convert.ToInt32(b);
                    Nomen.id_stanka = Convert.ToInt32(d);
                    Nomen.id_instrymenta = Convert.ToInt32(i);
                    Nomen.id_sklada = Convert.ToInt32(f);
                    db.Diplom_Ispolzovanie_Instr.Add(Nomen);
                    db.SaveChanges();
                    System.Windows.MessageBox.Show("Данные добавлены!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch
            {
                System.Windows.MessageBox.Show("Ошибка", "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            DateDataIspInstr.Text = "";
            txtKolIspInstr.Text = "";
            DateDataSpisIspInstr.Text = "";
            ComboIdSot.Text = "";
            ComboIdStan.Text = "";
            ComboIdInstr.Text = "";
            ComboIdSklada.Text = "";
        }

        private void IzmenIspInstr_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtIdIspolInstr.Text))
                {
                    MessageBox.Show("Введите ID номенклатуры для изменения", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                int b = Convert.ToInt32(txtIdIspolInstr.Text);
                var Izmen = db.Diplom_Ispolzovanie_Instr.FirstOrDefault(id => id.ID_Ispolzovaniya_Instr == b);

                if (Izmen == null)
                {
                    MessageBox.Show("Номенклатура с таким ID не найдена", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (DateDataIspInstr.SelectedDate.HasValue)
                {
                    Izmen.Data_Ispolzovaniya = DateDataIspInstr.SelectedDate.Value;
                }

                if (!string.IsNullOrWhiteSpace(txtKolIspInstr.Text))
                {
                    Izmen.Kolichestvo = txtKolIspInstr.Text;
                }

                if (DateDataSpisIspInstr.SelectedDate.HasValue)
                {
                    Izmen.Spisanie_instrumenta = DateDataSpisIspInstr.SelectedDate.Value;
                }

                if (ComboIdSot.SelectedItem != null)
                {
                    var c = db.Diplom_Sotrydnik.Where(a => a.Familiya == ComboIdSot.Text).Select(a => a.ID_sotrydnika).SingleOrDefault();
                    Izmen.id_sotrudnika = Convert.ToInt32(c);
                }
                if (ComboIdStan.SelectedItem != null)
                {
                    var d = db.Diplom_Stanok.Where(a => a.Nazvanie == ComboIdStan.Text).Select(a => a.ID_Stanka).SingleOrDefault();
                    Izmen.id_stanka = Convert.ToInt32(d);
                }
                if (ComboIdInstr.SelectedItem != null)
                {
                    var i = db.Diplom_Instryment.Where(a => a.Nazvanie == ComboIdInstr.Text).Select(a => a.ID_Instrumenta).SingleOrDefault();
                    Izmen.id_instrymenta = Convert.ToInt32(i);
                }
                if (ComboIdSklada.SelectedItem != null)
                {
                    var f = db.Diplom_Sklad.Where(a => a.Postavschik == ComboIdSklada.Text).Select(a => a.ID_sklada).SingleOrDefault();
                    Izmen.id_sklada = Convert.ToInt32(f);
                }

                db.SaveChanges();
                MessageBox.Show("Данные изменены!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);

                // Очистка полей после успешного обновления
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void ClearFields()
        {
            txtIdIspolInstr.Text = "";
            DateDataIspInstr.SelectedDate = null;
            txtKolIspInstr.Text = "";
            DateDataSpisIspInstr.SelectedDate = null;
            ComboIdSot.SelectedItem = null;
            ComboIdStan.SelectedItem = null;
            ComboIdInstr.SelectedItem = null;
            ComboIdSklada.SelectedItem = null;
        }

        private void YdalIspInstr_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (txtIdIspolInstr.Text == "")
                {
                    System.Windows.MessageBox.Show("Вы ввели не все данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);

                }
                else
                {
                    int num = Convert.ToInt32(txtIdIspolInstr.Text);
                    var nomen = db.Diplom_Ispolzovanie_Instr.Where(w => w.ID_Ispolzovaniya_Instr == num).FirstOrDefault();
                    db.Diplom_Ispolzovanie_Instr.Remove(nomen);
                    db.SaveChanges();
                    MessageBox.Show("Запись успешно удалена!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch
            {
                System.Windows.MessageBox.Show("Ошибка", "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            txtIdIspolInstr.Text = "";
        }

        private void ObnovIspInstr_Click(object sender, RoutedEventArgs e)
        {
            IspolInstrIspInstr.ItemsSource = db.Diplom_Ispolzovanie_Instr.ToList();
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            Forms.Glavnaya glav = new Forms.Glavnaya();
            glav.Show();
            this.Close();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }

        private void ComboFilterSot_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ComboFilterIspInstr.SelectedItem != null)
            {
                string selectedDateStr = ComboFilterIspInstr.SelectedItem.ToString();
                DateTime selectedDate = DateTime.ParseExact(selectedDateStr, "dd.MM.yyyy", CultureInfo.InvariantCulture);

                IspolInstrIspInstr.ItemsSource = db.Diplom_Ispolzovanie_Instr
                    .Where(n => n.Spisanie_instrumenta.HasValue &&
                           DbFunctions.TruncateTime(n.Spisanie_instrumenta) == DbFunctions.TruncateTime(selectedDate))
                    .ToList();
            }
        }

        private void SortAZ_Click(object sender, RoutedEventArgs e)
        {
            IspolInstrIspInstr.ItemsSource = db.Diplom_Ispolzovanie_Instr.OrderBy(ChenB => ChenB.Spisanie_instrumenta).ToList();
        }

        private void SortZA_Click(object sender, RoutedEventArgs e)
        {
            IspolInstrIspInstr.ItemsSource = db.Diplom_Ispolzovanie_Instr.OrderByDescending(ChenB => ChenB.Spisanie_instrumenta).ToList();
        }

        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            string Poisk = txtSearch.Text.ToLower();
            DateTime? searchDate = null;

            // Попытка преобразовать строку поиска в дату
            if (DateTime.TryParse(Poisk, out DateTime parsedDate))
            {
                searchDate = parsedDate.Date; // Приводим к дате без времени
                Console.WriteLine("Parsed Date: " + parsedDate);
            }
            else
            {
                Console.WriteLine("Failed to parse date from: " + Poisk);
            }

            Console.WriteLine("Search Date: " + searchDate);

            IspolInstrIspInstr.ItemsSource = db.Diplom_Ispolzovanie_Instr.ToList().Where(q =>
                (searchDate.HasValue && q.Data_Ispolzovaniya.HasValue && q.Data_Ispolzovaniya.Value.Date == searchDate.Value) ||
                q.Kolichestvo.ToLower().Contains(Poisk) ||
                (searchDate.HasValue && q.Spisanie_instrumenta.HasValue && q.Spisanie_instrumenta.Value.Date == searchDate.Value) ||
                q.Diplom_Sotrydnik.Familiya.ToLower().Contains(Poisk) ||
                q.Diplom_Stanok.Nazvanie.ToLower().Contains(Poisk) ||
                q.Diplom_Instryment.Nazvanie.ToLower().Contains(Poisk) ||
                q.Diplom_Sklad.Postavschik.ToLower().Contains(Poisk)
            ).ToList();
        }

        private void txtIdIspolInstr_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9/]+");
            e.Handled = regex.IsMatch(e.Text);
        }
    }
}
