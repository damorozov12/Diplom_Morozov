﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplomm.Forms
{
    /// <summary>
    /// Логика взаимодействия для Glavnaya.xaml
    /// </summary>
    public partial class Glavnaya : Window
    {
        public Glavnaya()
        {
            InitializeComponent();
        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            Prof.Content = App.CurrentUser.Familiya + " " + App.CurrentUser.Imya + " " + App.CurrentUser.Otvhestvo;
            if (App.CurrentUser.Rol != 1)
            {
                Sotrydnik.IsEnabled = false;
            }
        }

        private void Nomenklatura_Click(object sender, RoutedEventArgs e)
        {
            Forms.Nomenklatura glav = new Forms.Nomenklatura();
            glav.Show();
            this.Close();
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow glav = new MainWindow();
            glav.Show();
            this.Close();

        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }

        private void Sklad_Click(object sender, RoutedEventArgs e)
        {
            Forms.Sklad glav = new Forms.Sklad();
            glav.Show();
            this.Close();
        }

        private void Sotrydnik_Click(object sender, RoutedEventArgs e)
        {
                Forms.Sotrudniki glav = new Forms.Sotrudniki();
                glav.Show();
                this.Close();
        }

        private void Ispolzovanie_Instr_Click(object sender, RoutedEventArgs e)
        {
            Forms.Ispolzovanie_Instr glav = new Forms.Ispolzovanie_Instr();
            glav.Show();
            this.Close();
        }

        private void Postyplenie_Instr_Click(object sender, RoutedEventArgs e)
        {
            Forms.Postyplenie_Instr glav = new Forms.Postyplenie_Instr();
            glav.Show();
            this.Close();
        }

        private void Instryment_Click(object sender, RoutedEventArgs e)
        {
            Forms.Instryment glav = new Forms.Instryment();
            glav.Show();
            this.Close();
        }

        private void Stanok_Click(object sender, RoutedEventArgs e)
        {
            Forms.Stanok glav = new Forms.Stanok();
            glav.Show();
            this.Close();
        }

        private void Ychastok_Click(object sender, RoutedEventArgs e)
        {
            Forms.Ychastok glav = new Forms.Ychastok();
            glav.Show();
            this.Close();
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }

        private void Profil_Click(object sender, RoutedEventArgs e)
        {
            Lichnii glav = new Lichnii();
            glav.Show();
            this.Close();
        }
    }
}
