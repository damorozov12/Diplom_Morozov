﻿using Diplomm.BD;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplomm.Forms
{
    /// <summary>
    /// Логика взаимодействия для Instryment.xaml
    /// </summary>
    public partial class Instryment : Window
    {
        BD.user168_dbEntities db = new BD.user168_dbEntities();
        public Instryment()
        {
            db = new BD.user168_dbEntities();
            InitializeComponent();
            InstrymentiInstr.ItemsSource = db.Diplom_Instryment.ToList();
            var Sot = db.Diplom_Tip_Instrymenta.ToList();
            ComboTipInstr.ItemsSource = Sot;
            ComboTipInstr.DisplayMemberPath = "tip";

            var itemNaz = db.Diplom_Instryment.Select(n => n.Nazvanie).ToList();
            foreach (String ITEM in itemNaz)
            {
                ComboFilterInstr.Items.Add(ITEM);
            }
            if (App.CurrentUser.Rol == 1 || App.CurrentUser.Rol == 2) //Если роль 1 (например Админ)
            { //То кнопки редактирования и просмотра видны
                DobavInstr.Visibility = Visibility.Visible;
                YdalInstr.Visibility = Visibility.Visible;
            }
            else //Для всех других ролей
            { //Данные кнопки не видны
                DobavInstr.Visibility = Visibility.Collapsed;
                YdalInstr.Visibility = Visibility.Collapsed;
            }
        }

        private void DobavInstr_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (txtNazInstr.Text == "" || ComboTipInstr.Text == "" || txtModInstr.Text == "" || txtMestoInstr.Text == "" || txtSrokInstr.Text == "" )
                {
                    System.Windows.MessageBox.Show("Вы ввели не все данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    var f = db.Diplom_Tip_Instrymenta.Where(a => a.tip == ComboTipInstr.Text).Select(a => a.ID_Tipa_Instrymenta).SingleOrDefault();
                    Diplom_Instryment Sot = new Diplom_Instryment();
                    Sot.Nazvanie = txtNazInstr.Text;
                    Sot.Tip = Convert.ToInt32(f);
                    Sot.Model = txtModInstr.Text;
                    Sot.Mesto_hraneniya = txtMestoInstr.Text;
                    Sot.Srok_slyjbi = txtSrokInstr.Text;

                    db.Diplom_Instryment.Add(Sot);
                    db.SaveChanges();
                    System.Windows.MessageBox.Show("Данные добавлены!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch
            {
                System.Windows.MessageBox.Show("Ошибка", "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            txtNazInstr.Text = "";
            ComboTipInstr.Text = "";
            txtModInstr.Text = "";
            txtMestoInstr.Text = "";
            txtSrokInstr.Text = "";
        }

        private void IzmenInstr_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtIdInstr.Text))
                {
                    MessageBox.Show("Введите ID номенклатуры для изменения", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                int b = Convert.ToInt32(txtIdInstr.Text);
                var Izmen = db.Diplom_Instryment.FirstOrDefault(id => id.ID_Instrumenta == b);

                if (Izmen == null)
                {
                    MessageBox.Show("Номенклатура с таким ID не найдена", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (!string.IsNullOrWhiteSpace(txtNazInstr.Text))
                {
                    Izmen.Nazvanie = txtNazInstr.Text;
                }

                if (ComboTipInstr.SelectedItem != null)
                {
                    var f = db.Diplom_Tip_Instrymenta.Where(a => a.tip == ComboTipInstr.Text).Select(a => a.ID_Tipa_Instrymenta).SingleOrDefault();
                    Izmen.Tip = Convert.ToInt32(f);
                }

                if (!string.IsNullOrWhiteSpace(txtModInstr.Text))
                {
                    Izmen.Model = txtModInstr.Text;
                }

                if (!string.IsNullOrWhiteSpace(txtMestoInstr.Text))
                {
                    Izmen.Mesto_hraneniya = txtMestoInstr.Text;
                }
                if (!string.IsNullOrWhiteSpace(txtSrokInstr.Text))
                {
                    Izmen.Srok_slyjbi = txtSrokInstr.Text;
                }
                db.SaveChanges();
                MessageBox.Show("Данные изменены!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);

                // Очистка полей после успешного обновления
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void ClearFields()
        {
            txtIdInstr.Text = "";
            txtNazInstr.Text = "";
            ComboTipInstr.SelectedItem = null;
            txtModInstr.Text = "";
            txtMestoInstr.Text = "";
            txtSrokInstr.Text = "";
        }

        private void YdalInstr_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (txtIdInstr.Text == "")
                {
                    System.Windows.MessageBox.Show("Вы ввели не все данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);

                }
                else
                {
                    int num = Convert.ToInt32(txtIdInstr.Text);
                    var sot = db.Diplom_Instryment.Where(w => w.ID_Instrumenta == num).FirstOrDefault();
                    db.Diplom_Instryment.Remove(sot);
                    db.SaveChanges();
                    MessageBox.Show("Запись успешно удалена!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch
            {
                System.Windows.MessageBox.Show("Ошибка", "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            txtIdInstr.Text = "";
        }

        private void ObnovInstr_Click(object sender, RoutedEventArgs e)
        {
            InstrymentiInstr.ItemsSource = db.Diplom_Instryment.ToList();
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            Forms.Glavnaya glav = new Forms.Glavnaya();
            glav.Show();
            this.Close();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }

        private void ComboFilterInstr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ComboFilterInstr.SelectedIndex == 0 || ComboFilterInstr.SelectedItem.ToString() == "Все")
            {
                InstrymentiInstr.ItemsSource = db.Diplom_Instryment.ToList();
            }
            else
            {
                string selectedFamiliya = ComboFilterInstr.SelectedItem.ToString();
                InstrymentiInstr.ItemsSource = db.Diplom_Instryment
                                           .Where(n => n.Nazvanie == selectedFamiliya)
                                           .ToList();
            }
        }

        private void SortAZ_Click(object sender, RoutedEventArgs e)
        {
            InstrymentiInstr.ItemsSource = db.Diplom_Instryment.OrderBy(ChenB => ChenB.Nazvanie).ToList();
        }

        private void SortZA_Click(object sender, RoutedEventArgs e)
        {
            InstrymentiInstr.ItemsSource = db.Diplom_Instryment.OrderByDescending(ChenB => ChenB.Nazvanie).ToList();
        }

        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            string Poisk = txtSearch.Text;
            InstrymentiInstr.ItemsSource = db.Diplom_Instryment.ToList().Where(
                q => q.Nazvanie.ToLower().Contains(Poisk.ToLower()) || q.Diplom_Tip_Instrymenta.tip.ToLower().Contains(Poisk.ToLower()) || q.Model.ToLower().Contains(Poisk.ToLower()) || q.Mesto_hraneniya.ToLower().Contains(Poisk.ToLower()) || q.Srok_slyjbi.ToLower().Contains(Poisk.ToLower())
                ).ToList();
        }

        private void txtIdInstr_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9/]+");
            e.Handled = regex.IsMatch(e.Text);
        }
    }
}
