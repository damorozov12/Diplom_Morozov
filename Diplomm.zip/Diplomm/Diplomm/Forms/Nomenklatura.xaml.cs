﻿using Diplomm.BD;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Common.CommandTrees.ExpressionBuilder;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace Diplomm.Forms
{
    /// <summary>
    /// Логика взаимодействия для Nomenklatura.xaml
    /// </summary>
    public partial class Nomenklatura : Window
    {
        BD.user168_dbEntities db = new BD.user168_dbEntities();
        public Nomenklatura()
        {
            db = new BD.user168_dbEntities();
            InitializeComponent();
            Nomenklatuta.ItemsSource = db.Diplom_Nomenklatyra.ToList();
            var Nom = db.Diplom_Sklad.ToList();
            ComboIdSkladaNomen.ItemsSource = Nom;
            ComboIdSkladaNomen.DisplayMemberPath = "Postavschik";

            var itemNaz = db.Diplom_Nomenklatyra.Select(n => n.Nazvanie).ToList();
            foreach (String ITEM in itemNaz)
            {
                ComboFilterNomen.Items.Add(ITEM);
            }

            if (App.CurrentUser.Rol== 1|| App.CurrentUser.Rol == 2) //Если роль 1 (например Админ)
            { //То кнопки редактирования и просмотра видны
                DobavNomen.Visibility = Visibility.Visible;
                YdalNomen.Visibility = Visibility.Visible;
            }
            else //Для всех других ролей
            { //Данные кнопки не видны
                DobavNomen.Visibility = Visibility.Collapsed;
                YdalNomen.Visibility = Visibility.Collapsed;
            }

        }

        private void DobavNomen_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (txtNazNomen.Text == "" || txtYchasNomen.Text == "" || txtSpecNomen.Text == "" || txtObesNomen.Text == "" || txtKolNomen.Text == "" || txtPlanNomen.Text == "" || txtSHPZNomen.Text == "" ||
                    DateDataNomen.Text == "" || ComboIdSkladaNomen.Text == "")
                {
                    System.Windows.MessageBox.Show("Вы ввели не все данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    var f = db.Diplom_Sklad.Where(a => a.Postavschik == ComboIdSkladaNomen.Text).Select(a => a.ID_sklada).SingleOrDefault();
                    var Data = Convert.ToDateTime(DateDataNomen.Text);
                    int Obes = Convert.ToInt32(txtObesNomen.Text);
                    int Kolichestvo = Convert.ToInt32(txtKolNomen.Text);
                    int Plan = Convert.ToInt32(txtPlanNomen.Text);
                    Diplom_Nomenklatyra Nomen = new Diplom_Nomenklatyra();
                    Nomen.Nazvanie = txtNazNomen.Text;
                    Nomen.Ychastok = txtYchasNomen.Text;
                    Nomen.Specifikaciya = txtSpecNomen.Text;
                    Nomen.Obespecheno = Obes;
                    Nomen.Kolichestvo_na_Sklade = Kolichestvo;
                    Nomen.Plan_Obespecheniya = Plan;
                    Nomen.Partii = txtSHPZNomen.Text;
                    Nomen.Data_sdachi = Data;
                    Nomen.Id_Sklada = Convert.ToInt32(f);
                    db.Diplom_Nomenklatyra.Add(Nomen);
                    db.SaveChanges();
                    System.Windows.MessageBox.Show("Данные добавлены!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch
            {
                System.Windows.MessageBox.Show("Ошибка", "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            txtNazNomen.Text = "";
            txtYchasNomen.Text = "";
            txtSpecNomen.Text = "";
            txtObesNomen.Text = "";
            txtKolNomen.Text = "";
            txtPlanNomen.Text = "";
            txtSHPZNomen.Text = "";
            DateDataNomen.Text = "";
            ComboIdSkladaNomen.Text = "";
        }
        // Метод для загрузки данных и установки состояния поля Partii
        private void LoadData()
        {
            var data = db.Diplom_Nomenklatyra.ToList();

            // Установка данных в DataGrid
            Nomenklatuta.ItemsSource = data;

            // Установка состояния поля Partii
            SetPartiiReadonlyState();
        }

        // Метод для установки состояния поля Partii
        private void SetPartiiReadonlyState()
        {
            foreach (var item in Nomenklatuta.Items)
            {
                var nomenklaturaItem = item as Diplom_Nomenklatyra;

                if (nomenklaturaItem != null)
                {
                    // Проверка длины поля Partii и установка IsReadOnly
                    if (nomenklaturaItem.Partii.Length > 5)
                    {
                        txtSHPZNomen.IsReadOnly = true;
                        txtSHPZNomen.ToolTip = "У вас не достаточно прав для изменения этого поля.";
                    }
                    else
                    {
                        txtSHPZNomen.IsReadOnly = false;
                        txtSHPZNomen.ToolTip = null;
                    }
                }
            }
        }

        // Вызовите LoadData в методе, который загружает данные при открытии формы
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

        private void IzmenNomen_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtIdNomen.Text))
                {
                    MessageBox.Show("Введите ID номенклатуры для изменения", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                int b = Convert.ToInt32(txtIdNomen.Text);
                var Izmen = db.Diplom_Nomenklatyra.FirstOrDefault(id => id.ID_Nomeklatyri == b);

                if (Izmen == null)
                {
                    MessageBox.Show("Номенклатура с таким ID не найдена", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                string partii = txtSHPZNomen.Text;
                bool isAdmin = App.CurrentUser.Rol == 1; // Предполагается, что роль 1 - это Администратор

                if (!string.IsNullOrWhiteSpace(partii))
                {
                    if (!isAdmin && partii.Length > 5)
                    {
                        MessageBox.Show("У вас не достаточно прав для изменения данных более чем на 5 цифр", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                    else if (isAdmin && partii.Length > 10)
                    {
                        MessageBox.Show("Данные в поле 'ШПЗ' не могут содержать более 10 цифр", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    if (Izmen.Partii.Length > 5 && !isAdmin)
                    {
                        MessageBox.Show("Вы не можете изменить это поле, так как у вас не достаточно прав.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    Izmen.Partii = partii;
                }

                if (!string.IsNullOrWhiteSpace(txtNazNomen.Text))
                {
                    Izmen.Nazvanie = txtNazNomen.Text;
                }

                if (!string.IsNullOrWhiteSpace(txtYchasNomen.Text))
                {
                    Izmen.Ychastok = txtYchasNomen.Text;
                }

                if (!string.IsNullOrWhiteSpace(txtSpecNomen.Text))
                {
                    Izmen.Specifikaciya = txtSpecNomen.Text;
                }

                if (!string.IsNullOrWhiteSpace(txtObesNomen.Text))
                {
                    Izmen.Obespecheno = Convert.ToInt32(txtObesNomen.Text);
                }

                if (!string.IsNullOrWhiteSpace(txtKolNomen.Text))
                {
                    Izmen.Kolichestvo_na_Sklade = Convert.ToInt32(txtKolNomen.Text);
                }

                if (!string.IsNullOrWhiteSpace(txtPlanNomen.Text))
                {
                    Izmen.Plan_Obespecheniya = Convert.ToInt32(txtPlanNomen.Text);
                }

                if (DateDataNomen.SelectedDate.HasValue)
                {
                    Izmen.Data_sdachi = DateDataNomen.SelectedDate.Value;
                }

                if (ComboIdSkladaNomen.SelectedItem != null)
                {
                    var f = db.Diplom_Sklad.Where(a => a.Postavschik == ComboIdSkladaNomen.Text).Select(a => a.ID_sklada).SingleOrDefault();
                    Izmen.Id_Sklada = Convert.ToInt32(f);
                }

                db.SaveChanges();
                MessageBox.Show("Данные изменены!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);

                // Очистка полей после успешного обновления
                ClearFields();

                // Снова установите состояние поля Partii
                SetPartiiReadonlyState();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ClearFields()
        {
            txtIdNomen.Text = "";
            txtNazNomen.Text = "";
            txtYchasNomen.Text = "";
            txtSpecNomen.Text = "";
            txtObesNomen.Text = "";
            txtKolNomen.Text = "";
            txtPlanNomen.Text = "";
            txtSHPZNomen.Text = "";
            DateDataNomen.SelectedDate = null;
            ComboIdSkladaNomen.SelectedItem = null;
        }

        private void YdalNomen_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (txtIdNomen.Text=="")
                {
                    System.Windows.MessageBox.Show("Вы ввели не все данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);

                }
                else
                {
                    int num = Convert.ToInt32(txtIdNomen.Text);
                    var nomen = db.Diplom_Nomenklatyra.Where(w => w.ID_Nomeklatyri == num).FirstOrDefault();
                    db.Diplom_Nomenklatyra.Remove(nomen);
                    db.SaveChanges();
                    MessageBox.Show("Запись успешно удалена!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch
            {
                System.Windows.MessageBox.Show("Ошибка", "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            txtIdNomen.Text = "";
        }

        private void ObnovNomen_Click(object sender, RoutedEventArgs e)
        {
            Nomenklatuta.ItemsSource = db.Diplom_Nomenklatyra.ToList();
        }
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            Forms.Glavnaya glav = new Forms.Glavnaya();
            glav.Show();
            this.Close();
        }
        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }

        private void ComboFilterNomen_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ComboFilterNomen.SelectedIndex == 0 || ComboFilterNomen.SelectedItem.ToString() == "Все")
            {
                Nomenklatuta.ItemsSource = db.Diplom_Nomenklatyra.ToList();
            }
            else
            {
                string selectedNazvanie = ComboFilterNomen.SelectedItem.ToString();
                Nomenklatuta.ItemsSource = db.Diplom_Nomenklatyra
                                           .Where(n => n.Nazvanie == selectedNazvanie)
                                           .ToList();
            }
        }

        private void SortAZ_Click(object sender, RoutedEventArgs e)
        {
            Nomenklatuta.ItemsSource = db.Diplom_Nomenklatyra.OrderBy(ChenB => ChenB.Nazvanie).ToList();
            
        }

        private void SortZA_Click(object sender, RoutedEventArgs e)
        {
            Nomenklatuta.ItemsSource = db.Diplom_Nomenklatyra.OrderByDescending(ChenB => ChenB.Nazvanie).ToList();
        }

        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            string Poisk = txtSearch.Text;
            Nomenklatuta.ItemsSource = db.Diplom_Nomenklatyra.ToList().Where(
                q => q.Nazvanie.ToLower().Contains(Poisk.ToLower()) || q.Ychastok.ToLower().Contains(Poisk.ToLower()) || q.Specifikaciya.ToLower().Contains(Poisk.ToLower()) || q.Partii.ToLower().Contains(Poisk.ToLower()) || q.Diplom_Sklad.Postavschik.ToLower().Contains(Poisk.ToLower())
                ).ToList();
        }

        private void SaveToExcel_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Microsoft.Office.Interop.Excel.Application excelApp = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel.Workbook workbook = excelApp.Workbooks.Add();
                Microsoft.Office.Interop.Excel.Worksheet worksheet = workbook.Sheets[1];
                int row = 1;
                int col = 1;

                // Добавьте заголовки столбцов
                foreach (DataGridColumn column in Nomenklatuta.Columns)
                {
                    worksheet.Cells[row, col] = column.Header;
                    col++;
                }

                // Добавьте данные из DataGrid
                foreach (var item in Nomenklatuta.Items)
                {
                    row++;
                    col = 1;
                    foreach (DataGridColumn column in Nomenklatuta.Columns)
                    {
                        var cellValue = (column.GetCellContent(item) as TextBlock)?.Text;
                        worksheet.Cells[row, col] = cellValue;
                        col++;
                    }
                }

                // Сохраните файл Excel
                SaveFileDialog saveDialog = new SaveFileDialog();
                saveDialog.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
                saveDialog.FilterIndex = 1;
                saveDialog.RestoreDirectory = true;

                if (saveDialog.ShowDialog() == true)
                {
                    workbook.SaveAs(saveDialog.FileName);
                    excelApp.Visible = true;
                }
                else
                {
                    excelApp.Quit();
                }
            }
            catch
            {
                System.Windows.MessageBox.Show("Ошибка", "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void txtIdNomen_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9/]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void txtYchasNomen_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9/]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void txtObesNomen_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9/]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void txtKolNomen_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9/]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void txtPlanNomen_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9/]+");
            e.Handled = regex.IsMatch(e.Text);
        }

    }
}
 