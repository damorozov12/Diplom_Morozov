﻿using Diplomm.BD;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplomm.Forms
{
    /// <summary>
    /// Логика взаимодействия для Ychastok.xaml
    /// </summary>
    public partial class Ychastok : Window
    {
        BD.user168_dbEntities db = new BD.user168_dbEntities();
        public Ychastok()
        {
            db = new BD.user168_dbEntities();
            InitializeComponent();
            YchastokYch.ItemsSource = db.Diplom_Ychastok.ToList();
            var Ych = db.Diplom_Statys_Ychastka.ToList();
            ComboStatysYch.ItemsSource = Ych;
            ComboStatysYch.DisplayMemberPath = "Statys";

            var itemNaz = db.Diplom_Ychastok.Select(n => n.Nazvanie).ToList();
            foreach (String ITEM in itemNaz)
            {
                ComboFilterYch.Items.Add(ITEM);
            }
            if (App.CurrentUser.Rol == 1) //Если роль 1 (например Админ)
            { //То кнопки редактирования и просмотра видны
                DobavYch.Visibility = Visibility.Visible;
                YdalYch.Visibility = Visibility.Visible;
            }
            else //Для всех других ролей
            { //Данные кнопки не видны
                DobavYch.Visibility = Visibility.Collapsed;
                YdalYch.Visibility = Visibility.Collapsed;
            }
        }

        private void DobavYch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (txtNazYch.Text == "" || txtRykYch.Text == "" || txtMesYch.Text == "" || ComboStatysYch.Text == "" || txtOpisYch.Text == "")
                {
                    System.Windows.MessageBox.Show("Вы ввели не все данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    var f = db.Diplom_Statys_Ychastka.Where(a => a.Statys == ComboStatysYch.Text).Select(a => a.ID_Statysa_Ychastka).SingleOrDefault();
                    Diplom_Ychastok Ych = new Diplom_Ychastok();
                    Ych.Nazvanie = txtNazYch.Text;
                    Ych.Rykovoditel_ychastka = txtRykYch.Text;
                    Ych.Mestopolojenie = txtMesYch.Text;
                    Ych.Statys = Convert.ToInt32(f);
                    Ych.Opisanie = txtOpisYch.Text;

                    db.Diplom_Ychastok.Add(Ych);
                    db.SaveChanges();
                    System.Windows.MessageBox.Show("Данные добавлены!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch
            {
                System.Windows.MessageBox.Show("Ошибка", "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            txtNazYch.Text = "";
            txtRykYch.Text = "";
            txtMesYch.Text = "";
            ComboStatysYch.Text = "";
            txtOpisYch.Text = "";
        }

        private void IzmenYch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (App.CurrentUser.Rol == 1)
                {
                    if (string.IsNullOrWhiteSpace(txtIdYch.Text))
                    {
                        MessageBox.Show("Введите ID номенклатуры для изменения", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    int b = Convert.ToInt32(txtIdYch.Text);
                    var Izmen = db.Diplom_Ychastok.FirstOrDefault(id => id.ID_Ychastka == b);

                    if (Izmen == null)
                    {
                        MessageBox.Show("Номенклатура с таким ID не найдена", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    if (!string.IsNullOrWhiteSpace(txtNazYch.Text))
                    {
                        Izmen.Nazvanie = txtNazYch.Text;
                    }

                    if (!string.IsNullOrWhiteSpace(txtRykYch.Text))
                    {
                        Izmen.Rykovoditel_ychastka = txtRykYch.Text;
                    }

                    if (!string.IsNullOrWhiteSpace(txtMesYch.Text))
                    {
                        Izmen.Mestopolojenie = txtMesYch.Text;
                    }

                    if (ComboStatysYch.SelectedItem != null)
                    {
                        var f = db.Diplom_Statys_Ychastka.Where(a => a.Statys == ComboStatysYch.Text).Select(a => a.ID_Statysa_Ychastka).SingleOrDefault();
                        Izmen.Statys = Convert.ToInt32(f);
                    }

                    if (!string.IsNullOrWhiteSpace(txtOpisYch.Text))
                    {
                        Izmen.Opisanie = txtOpisYch.Text;
                    }
                    db.SaveChanges();
                    MessageBox.Show("Данные изменены!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else if (App.CurrentUser.Rol == 2 || App.CurrentUser.Rol == 3)
                {
                    if (string.IsNullOrWhiteSpace(txtIdYch.Text))
                    {
                        MessageBox.Show("Введите ID номенклатуры для изменения", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    int b = Convert.ToInt32(txtIdYch.Text);
                    var Izmen = db.Diplom_Ychastok.FirstOrDefault(id => id.ID_Ychastka == b);

                    if (Izmen == null)
                    {
                        MessageBox.Show("Номенклатура с таким ID не найдена", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                    if (!string.IsNullOrWhiteSpace(txtNazYch.Text))
                    {
                        MessageBox.Show("У Вас недостаточно прав для изменения Названия", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    if (!string.IsNullOrWhiteSpace(txtRykYch.Text))
                    {
                        MessageBox.Show("У Вас недостаточно прав для изменения Руководителя участка", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    if (!string.IsNullOrWhiteSpace(txtMesYch.Text))
                    {
                        MessageBox.Show("У Вас недостаточно прав для изменения Местоположения", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    if (ComboStatysYch.SelectedItem != null)
                    {
                        var f = db.Diplom_Statys_Ychastka.Where(a => a.Statys == ComboStatysYch.Text).Select(a => a.ID_Statysa_Ychastka).SingleOrDefault();
                        Izmen.Statys = Convert.ToInt32(f);
                    }

                    if (!string.IsNullOrWhiteSpace(txtOpisYch.Text))
                    {
                        Izmen.Opisanie = txtOpisYch.Text;
                    }
                    db.SaveChanges();
                    MessageBox.Show("Данные изменены!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);

                }
                // Очистка полей после успешного обновления
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void ClearFields()
        {
            txtIdYch.Text = "";
            txtNazYch.Text = "";
            txtRykYch.Text = "";
            txtMesYch.Text = "";
            ComboStatysYch.SelectedItem = null;
            txtOpisYch.Text = "";
        }

        private void YdalYch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (txtIdYch.Text == "")
                {
                    System.Windows.MessageBox.Show("Вы ввели не все данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);

                }
                else
                {
                    int num = Convert.ToInt32(txtIdYch.Text);
                    var ych = db.Diplom_Ychastok.Where(w => w.ID_Ychastka == num).FirstOrDefault();
                    db.Diplom_Ychastok.Remove(ych);
                    db.SaveChanges();
                    MessageBox.Show("Запись успешно удалена!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch
            {
                System.Windows.MessageBox.Show("Ошибка", "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            txtIdYch.Text = "";
        }

        private void ObnovYch_Click(object sender, RoutedEventArgs e)
        {
            YchastokYch.ItemsSource = db.Diplom_Ychastok.ToList();
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            Forms.Glavnaya glav = new Forms.Glavnaya();
            glav.Show();
            this.Close();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }
        private void ComboFilterYch_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ComboFilterYch.SelectedIndex == 0 || ComboFilterYch.SelectedItem.ToString() == "Все")
            {
                YchastokYch.ItemsSource = db.Diplom_Ychastok.ToList();
            }
            else
            {
                string selectedNazvanie = ComboFilterYch.SelectedItem.ToString();
                YchastokYch.ItemsSource = db.Diplom_Ychastok
                                           .Where(n => n.Nazvanie == selectedNazvanie)
                                           .ToList();
            }
        }

        private void SortAZ_Click(object sender, RoutedEventArgs e)
        {
            YchastokYch.ItemsSource = db.Diplom_Ychastok.OrderBy(ChenB => ChenB.Nazvanie).ToList();
        }

        private void SortZA_Click(object sender, RoutedEventArgs e)
        {
            YchastokYch.ItemsSource = db.Diplom_Ychastok.OrderByDescending(ChenB => ChenB.Nazvanie).ToList();
        }

        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            string Poisk = txtSearch.Text;
            YchastokYch.ItemsSource = db.Diplom_Ychastok.ToList().Where(
                q => q.Nazvanie.ToLower().Contains(Poisk.ToLower()) || q.Rykovoditel_ychastka.ToLower().Contains(Poisk.ToLower()) || q.Mestopolojenie.ToLower().Contains(Poisk.ToLower()) || q.Opisanie.ToLower().Contains(Poisk.ToLower()) || q.Diplom_Statys_Ychastka.Statys.ToLower().Contains(Poisk.ToLower())
                ).ToList();
        }

        private void txtIdYch_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9/]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void txtNazYch_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9/]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            if (App.CurrentUser.Rol == 1)
            {
                txtNazYch.IsReadOnly = false;
                txtRykYch.IsReadOnly = false;
                txtMesYch.IsReadOnly = false;
            }
            else
            {
                // Блокировка текстовых полей, кроме пароля
                txtNazYch.IsEnabled = false;
                txtRykYch.IsEnabled = false;
                txtMesYch.IsEnabled = false;
            }
        }
    }
}
