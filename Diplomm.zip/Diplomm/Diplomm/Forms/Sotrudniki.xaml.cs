﻿using Diplomm.BD;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UnitTestLogin;

namespace Diplomm.Forms
{
    /// <summary>
    /// Логика взаимодействия для Sotrudniki.xaml
    /// </summary>
    public partial class Sotrudniki : Window
    {
        BD.user168_dbEntities db = new BD.user168_dbEntities();
     
        public Sotrudniki()
        {
            db = new BD.user168_dbEntities();
            InitializeComponent();
            SotrudnikiSot.ItemsSource = db.Diplom_Sotrydnik.ToList();
            var Sot = db.Diplom_Rol_Sotrudnik.ToList();
            ComboIdRolSot.ItemsSource = Sot;
            ComboIdRolSot.DisplayMemberPath = "rol";

            var itemNaz = db.Diplom_Sotrydnik.Select(n => n.Familiya).ToList();
            foreach (String ITEM in itemNaz)
            {
                ComboFilterSot.Items.Add(ITEM);
            }
            if (App.CurrentUser.Rol == 1 || App.CurrentUser.Rol == 2) //Если роль 1 (например Админ)
            { //То кнопки редактирования и просмотра видны
                DobavSot.Visibility = Visibility.Visible;
                YdalSot.Visibility = Visibility.Visible;
            }
            else //Для всех других ролей
            { //Данные кнопки не видны
                DobavSot.Visibility = Visibility.Collapsed;
                YdalSot.Visibility = Visibility.Collapsed;
            }
        }

        private void DobavSot_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (txtFamSot.Text == "" || txtImyaSot.Text == "" || txtOtchSot.Text == "" || txtTelSot.Text == "" || txtStajSot.Text == "" || ComboIdRolSot.Text == "" || txtLogSot.Text == "" ||
                    txtPassSot.Text == "")
                {
                    System.Windows.MessageBox.Show("Вы ввели не все данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    var f = db.Diplom_Rol_Sotrudnik.Where(a => a.rol == ComboIdRolSot.Text).Select(a => a.ID_Roli).SingleOrDefault();
                    Diplom_Sotrydnik Sot = new Diplom_Sotrydnik();
                    Sot.Familiya = txtFamSot.Text;
                    Sot.Imya = txtImyaSot.Text;
                    Sot.Otvhestvo = txtOtchSot.Text;
                    Sot.Telefon = txtTelSot.Text;
                    Sot.Staj = txtStajSot.Text;
                    Sot.Rol = Convert.ToInt32(f); 
                    Sot.Login = txtLogSot.Text;
                    Sot.Password = txtPassSot.Text;

                    UnitTest1 test = new UnitTest1();
                    test.TestMethod1($"{txtLogSot.Text}");

                    db.Diplom_Sotrydnik.Add(Sot);
                    db.SaveChanges();
                    System.Windows.MessageBox.Show("Данные добавлены!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch
            {
                System.Windows.MessageBox.Show("Ошибка", "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            txtFamSot.Text = "";
            txtImyaSot.Text = "";
            txtOtchSot.Text = "";
            txtTelSot.Text = "";
            txtStajSot.Text = "";
            ComboIdRolSot.Text = "";
            txtLogSot.Text = "";
            txtPassSot.Text = "";
        }

        private void IzmenSot_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtIdSot.Text))
                {
                    MessageBox.Show("Введите ID номенклатуры для изменения", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                int b = Convert.ToInt32(txtIdSot.Text);
                var Izmen = db.Diplom_Sotrydnik.FirstOrDefault(id => id.ID_sotrydnika == b);

                if (Izmen == null)
                {
                    MessageBox.Show("Номенклатура с таким ID не найдена", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (!string.IsNullOrWhiteSpace(txtFamSot.Text))
                {
                    Izmen.Familiya = txtFamSot.Text;
                }

                if (!string.IsNullOrWhiteSpace(txtImyaSot.Text))
                {
                    Izmen.Imya = txtImyaSot.Text;
                }

                if (!string.IsNullOrWhiteSpace(txtOtchSot.Text))
                {
                    Izmen.Otvhestvo = txtOtchSot.Text;
                }

                if (!string.IsNullOrWhiteSpace(txtTelSot.Text))
                {
                    Izmen.Telefon = txtTelSot.Text;
                }

                if (!string.IsNullOrWhiteSpace(txtStajSot.Text))
                {
                    Izmen.Staj = txtStajSot.Text;
                }
                 if (ComboIdRolSot.SelectedItem != null)
                {
                    var f = db.Diplom_Rol_Sotrudnik.Where(a => a.rol == ComboIdRolSot.Text).Select(a => a.ID_Roli).SingleOrDefault();
                    Izmen.Rol = Convert.ToInt32(f);
                }

                if (!string.IsNullOrWhiteSpace(txtLogSot.Text))
                {
                    Izmen.Login = txtLogSot.Text;
                }

                if (!string.IsNullOrWhiteSpace(txtPassSot.Text))
                {
                    Izmen.Password = txtPassSot.Text;
                }
                db.SaveChanges();
                MessageBox.Show("Данные изменены!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);

                // Очистка полей после успешного обновления
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void ClearFields()
        {
            txtIdSot.Text = "";
            txtFamSot.Text = "";
            txtImyaSot.Text = "";
            txtOtchSot.Text = "";
            txtTelSot.Text = "";
            txtStajSot.Text = "";
            ComboIdRolSot.SelectedItem = null;
            txtLogSot.Text = "";
            txtPassSot.Text = "";
        }

        private void YdalSot_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (txtIdSot.Text == "")
                {
                    System.Windows.MessageBox.Show("Вы ввели не все данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);

                }
                else
                {
                    int num = Convert.ToInt32(txtIdSot.Text);
                    var sot = db.Diplom_Sotrydnik.Where(w => w.ID_sotrydnika == num).FirstOrDefault();
                    db.Diplom_Sotrydnik.Remove(sot);
                    db.SaveChanges();
                    MessageBox.Show("Запись успешно удалена!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch
            {
                System.Windows.MessageBox.Show("Ошибка", "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            txtIdSot.Text = "";
        }

        private void ObnovSot_Click(object sender, RoutedEventArgs e)
        {
            SotrudnikiSot.ItemsSource = db.Diplom_Sotrydnik.ToList();
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            Forms.Glavnaya glav = new Forms.Glavnaya();
            glav.Show();
            this.Close();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }

        private void ComboFilterSot_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ComboFilterSot.SelectedIndex == 0 || ComboFilterSot.SelectedItem.ToString() == "Все")
            {
                SotrudnikiSot.ItemsSource = db.Diplom_Sotrydnik.ToList();
            }
            else
            {
                string selectedFamiliya = ComboFilterSot.SelectedItem.ToString();
                SotrudnikiSot.ItemsSource = db.Diplom_Sotrydnik
                                           .Where(n => n.Familiya == selectedFamiliya)
                                           .ToList();
            }
        }

        private void SortAZ_Click(object sender, RoutedEventArgs e)
        {
            SotrudnikiSot.ItemsSource = db.Diplom_Sotrydnik.OrderBy(ChenB => ChenB.Familiya).ToList();
        }

        private void SortZA_Click(object sender, RoutedEventArgs e)
        {
            SotrudnikiSot.ItemsSource = db.Diplom_Sotrydnik.OrderByDescending(ChenB => ChenB.Familiya).ToList();
        }

        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            string Poisk = txtSearch.Text;
            SotrudnikiSot.ItemsSource = db.Diplom_Sotrydnik.ToList().Where(
                q => q.Familiya.ToLower().Contains(Poisk.ToLower()) || q.Imya.ToLower().Contains(Poisk.ToLower()) || q.Telefon.ToLower().Contains(Poisk.ToLower()) || q.Staj.ToLower().Contains(Poisk.ToLower()) || q.Diplom_Rol_Sotrudnik.rol.ToLower().Contains(Poisk.ToLower())
                ).ToList();
        }

        private void txtIdSot_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9/]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void txtFamSot_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^а-яА-Я]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void txtImyaSot_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^а-яА-Я]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void txtOtchSot_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^а-яА-Я]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void txtLogSot_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^a-zA-Z]+");
            e.Handled = regex.IsMatch(e.Text);
        }
    }
}
