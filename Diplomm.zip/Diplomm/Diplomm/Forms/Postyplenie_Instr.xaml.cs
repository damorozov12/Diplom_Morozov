﻿using Diplomm.BD;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplomm.Forms
{
    /// <summary>
    /// Логика взаимодействия для Postyplenie_Instr.xaml
    /// </summary>
    public partial class Postyplenie_Instr : Window
    {
        BD.user168_dbEntities db = new BD.user168_dbEntities();
        public Postyplenie_Instr()
        {
            db = new BD.user168_dbEntities();
            InitializeComponent();
            PostInstrPosInstr.ItemsSource = db.Diplom_Postyplenie_Instr.ToList();
            var Nom = db.Diplom_Instryment.ToList();
            ComboIdInstr.ItemsSource = Nom;
            ComboIdInstr.DisplayMemberPath = "Nazvanie";

            var itemNaz = db.Diplom_Postyplenie_Instr.Select(n => n.Data_postypleniya).Where(date => date.HasValue) // Фильтруем, чтобы исключить возможные NULL значения
           .ToList();

            foreach (DateTime? date in itemNaz)
            {
                if (date.HasValue) // Проверяем, не является ли дата NULL
                {
                    ComboFilterPostInstr.Items.Add(date.Value.ToString("dd.MM.yyyy"));
                }
            }

            if (App.CurrentUser.Rol == 1 || App.CurrentUser.Rol == 2) //Если роль 1 (например Админ)
            { //То кнопки редактирования и просмотра видны
                DobavPostInstr.Visibility = Visibility.Visible;
                YdalPostInstr.Visibility = Visibility.Visible;
            }
            else //Для всех других ролей
            { //Данные кнопки не видны
                DobavPostInstr.Visibility = Visibility.Collapsed;
                YdalPostInstr.Visibility = Visibility.Collapsed;
            }
        }

        private void DobavPostInstr_Click(object sender, RoutedEventArgs e)// кнопка добавления
        {
            try
            {
                if (DateDataPostInstr.Text == "" || txtKolPostInstr.Text == "" || ComboIdInstr.Text == "" )//Проверка на пустые поля
                {
                    System.Windows.MessageBox.Show("Вы ввели не все данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else//поля которые добавляются в БД
                {
                    
                    var i = db.Diplom_Instryment.Where(a => a.Nazvanie == ComboIdInstr.Text).Select(a => a.ID_Instrumenta).SingleOrDefault();
                    var Data = Convert.ToDateTime(DateDataPostInstr.Text);
                    Diplom_Postyplenie_Instr Nomen = new Diplom_Postyplenie_Instr();
                    Nomen.Data_postypleniya = Data;
                    Nomen.Kolichestvo = txtKolPostInstr.Text;
                    Nomen.id_instrymenta = Convert.ToInt32(i);
                    db.Diplom_Postyplenie_Instr.Add(Nomen);
                    db.SaveChanges();
                    System.Windows.MessageBox.Show("Данные добавлены!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch
            {
                System.Windows.MessageBox.Show("Ошибка", "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            DateDataPostInstr.Text = "";
            txtKolPostInstr.Text = "";
            ComboIdInstr.Text = "";
        }

        private void IzmenPostInstr_Click(object sender, RoutedEventArgs e)//кнопка изменения
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtIdPostInstr.Text))//Сообщение от том что нужно ввести ID
                {
                    MessageBox.Show("Введите ID номенклатуры для изменения", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                int b = Convert.ToInt32(txtIdPostInstr.Text);
                var Izmen = db.Diplom_Postyplenie_Instr.FirstOrDefault(id => id.ID_Postypleniya_Instr == b);

                if (Izmen == null)//Сообщение от том что  ID не найден
                {
                    MessageBox.Show("Номенклатура с таким ID не найдена", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (DateDataPostInstr.SelectedDate.HasValue)//изменение даты
                {
                    Izmen.Data_postypleniya = DateDataPostInstr.SelectedDate.Value;
                }

                if (!string.IsNullOrWhiteSpace(txtKolPostInstr.Text))//изменение количества
                {
                    Izmen.Kolichestvo = txtKolPostInstr.Text;
                }

                if (ComboIdInstr.SelectedItem != null)//изменение названия
                {
                    var i = db.Diplom_Instryment.Where(a => a.Nazvanie == ComboIdInstr.Text).Select(a => a.ID_Instrumenta).SingleOrDefault();
                    Izmen.id_instrymenta = Convert.ToInt32(i);
                }

                db.SaveChanges();
                MessageBox.Show("Данные изменены!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);

                // Очистка полей после успешного обновления
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
            private void ClearFields()
            {
            txtIdPostInstr.Text = "";
            DateDataPostInstr.SelectedDate = null;
            txtKolPostInstr.Text = "";
            ComboIdInstr.SelectedItem = null;
            }

        private void YdalPostInstr_Click(object sender, RoutedEventArgs e)//кнопка удаления
        {
            try
            {
                if (txtIdPostInstr.Text == "")//проверка на пустыетполя
                {
                    System.Windows.MessageBox.Show("Вы ввели не все данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);

                }
                else// поля которые удаляються в БД
                {
                    int num = Convert.ToInt32(txtIdPostInstr.Text);
                    var nomen = db.Diplom_Postyplenie_Instr.Where(w => w.ID_Postypleniya_Instr == num).FirstOrDefault();
                    db.Diplom_Postyplenie_Instr.Remove(nomen);
                    db.SaveChanges();
                    MessageBox.Show("Запись успешно удалена!", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch
            {
                System.Windows.MessageBox.Show("Ошибка", "Неполадки с сервером!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            txtIdPostInstr.Text = "";
        }

        private void ObnovPostInstr_Click(object sender, RoutedEventArgs e)
        {
            PostInstrPosInstr.ItemsSource = db.Diplom_Postyplenie_Instr.ToList();
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            Forms.Glavnaya glav = new Forms.Glavnaya();
            glav.Show();
            this.Close();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }

        private void ComboFilterPostInstr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ComboFilterPostInstr.SelectedItem != null)
            {
                string selectedDateStr = ComboFilterPostInstr.SelectedItem.ToString();
                DateTime selectedDate = DateTime.ParseExact(selectedDateStr, "dd.MM.yyyy", CultureInfo.InvariantCulture);

                PostInstrPosInstr.ItemsSource = db.Diplom_Postyplenie_Instr
                    .Where(n => n.Data_postypleniya.HasValue &&
                           DbFunctions.TruncateTime(n.Data_postypleniya) == DbFunctions.TruncateTime(selectedDate))
                    .ToList();
            }
        }

        private void SortAZ_Click(object sender, RoutedEventArgs e)
        {
            PostInstrPosInstr.ItemsSource = db.Diplom_Postyplenie_Instr.OrderBy(ChenB => ChenB.Data_postypleniya).ToList();
        }

        private void SortZA_Click(object sender, RoutedEventArgs e)
        {
            PostInstrPosInstr.ItemsSource = db.Diplom_Postyplenie_Instr.OrderByDescending(ChenB => ChenB.Data_postypleniya).ToList();
        }

        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            string Poisk = txtSearch.Text.ToLower();
            DateTime? searchDate = null;

            // Попытка преобразовать строку поиска в дату
            if (DateTime.TryParse(Poisk, out DateTime parsedDate))
            {
                searchDate = parsedDate.Date; // Приводим к дате без времени
                Console.WriteLine("Parsed Date: " + parsedDate);
            }
            else
            {
                Console.WriteLine("Failed to parse date from: " + Poisk);
            }

            Console.WriteLine("Search Date: " + searchDate);

            PostInstrPosInstr.ItemsSource = db.Diplom_Postyplenie_Instr.ToList().Where(q =>
                (searchDate.HasValue && q.Data_postypleniya.HasValue && q.Data_postypleniya.Value.Date == searchDate.Value) ||
                q.Kolichestvo.ToLower().Contains(Poisk) ||
                q.Diplom_Instryment.Nazvanie.ToLower().Contains(Poisk) 
            ).ToList();
        }

        private void txtIdPostInstr_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9/]+");
            e.Handled = regex.IsMatch(e.Text);
        }
    }
 }

