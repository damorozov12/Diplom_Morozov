﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Diplomm
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        BD.user168_dbEntities db = new BD.user168_dbEntities();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Vxod_Click(object sender, RoutedEventArgs e)// кнопка входа
        {
            try
            {
                if (txtLodin.Text == "" || pasboxPassword.Password == "")// проверка на пустые поля
                {
                    MessageBox.Show("Заполните пустые поля");
                }
                else
                {
                    var currentUser = App.Context.Diplom_Sotrydnik.FirstOrDefault(p => p.Login == txtLodin.Text && p.Password == pasboxPassword.Password); //Сравниваем значение текстовых блоков со значениями в таблице User

                    if (currentUser != null) //Такой пользователь найден в таблице User
                    {
                        App.CurrentUser = currentUser; //ПРИСВАИВАЕМ ЗНАЧЕНИЕ ПЕРЕМЕННОЙ
                        if (App.CurrentUser.Rol == 1)
                        {
                            MessageBox.Show("Вы авторизовались как Администратор.", "Добро пожаловать!", MessageBoxButton.OK, MessageBoxImage.None);//Сообщение о том что мы авторизовались как Администратор
                        }
                        else if (App.CurrentUser.Rol == 2)
                        {
                            MessageBox.Show("Вы авторизовались как Мастер участка.", "Добро пожаловать!", MessageBoxButton.OK, MessageBoxImage.None);//Сообщение о том что мы авторизовались как Мастер участка
                        }
                        else if (App.CurrentUser.Rol == 3)
                        {
                            MessageBox.Show("Вы авторизовались как Распределитель работ.", "Добро пожаловать!", MessageBoxButton.OK, MessageBoxImage.None);//Сообщение о том что мы авторизовались как Распределитель работ
                        }

                        Forms.Glavnaya glav = new Forms.Glavnaya();
                        glav.Show();
                        this.Close();
                    }
                    else //Если пользователя нет
                    {
                        MessageBox.Show("Пользователь с такими данными не найден.", "Ошибка",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch
            {
                MessageBox.Show("Ошибка сервера!");
            }
        }

        private void Exit_Click(object sender, RoutedEventArgs e)// кнопка выхода
        {
            Environment.Exit(0);
        }
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }
    }
}
