﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using ClassLibrary1;
using System.Windows;
namespace UnitTestLogin
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1(string txtLogSot)
        {

            string numder = txtLogSot;
            bool expected = true;
            Class1 a = new Class1();
            bool act1 = a.IsMail(numder);
            try
            {
                Assert.AreEqual(expected, act1);
                MessageBox.Show("True");
            }
            catch (Exception ex)
            {
                MessageBox.Show("False");
            }
        }
    }
}
